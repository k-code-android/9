package com.example.myfirstlocation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private LocationTracker gpsTracker;
    public  static final int RequestPermissionCode  = 1 ;
    private String Templat;
    private String Templon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Requesting runtime permission to access location.
        ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, RequestPermissionCode);


    }
    public void getMyLocation(View v)
    {
        EditText locationInfo= findViewById(R.id.locationInfoText);
        gpsTracker = new LocationTracker(MainActivity.this);
        if(gpsTracker.canGetLocation()){
            double latitude = gpsTracker.getLatitude();
            double longitude = gpsTracker.getLongitude();
            Templat = (String.valueOf(latitude));
            Templon = (String.valueOf(longitude));
            locationInfo.setText("My latitude =" +Templat +"\n\n" +"My longitude =" + Templon);

        }else{
            Toast.makeText(MainActivity.this,"Application cannot access location service. Application closing...", Toast.LENGTH_LONG).show();
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    finish();
                }
            }, 5000);

        }
    }


    @Override
    public void onRequestPermissionsResult(int RC, String per[], int[] PResult) {

        switch (RC) {

            case RequestPermissionCode:

                if (PResult.length > 0 && PResult[0] == PackageManager.PERMISSION_GRANTED) {

                    Toast.makeText(MainActivity.this,"Permission Granted, Now your application can access Location.", Toast.LENGTH_LONG).show();

                } else {

                    Toast.makeText(MainActivity.this,"Permission Canceled, Now your application cannot access location.", Toast.LENGTH_LONG).show();

                }
                break;
        }
    }


}
